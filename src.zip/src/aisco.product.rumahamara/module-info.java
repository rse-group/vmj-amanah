module aisco.product.rumahamara {
    requires vmj.routing.route;
    requires vmj.hibernate.integrator;
    
    requires net.bytebuddy;
    requires java.xml.bind;
    requires com.sun.xml.bind;
    requires com.fasterxml.classmate;
    requires jdk.unsupported;

    requires auth.storage.core;
    requires auth.storage.hibernate;
    requires auth.token.core;
    requires auth.management.core;
    requires auth.management.classic;
    requires auth.management.social;
    requires auth.token.hmac;
    requires auth.verifier.core;
    requires auth.verifier.manual;
    requires auth.verifier.google;
    requires auth.verifier.altgoogle;
    requires aisco.program.core;
    requires aisco.program.activity;
    requires aisco.chartofaccount.core;
    requires aisco.financialreport.core;
    requires aisco.financialreport.income;
    requires aisco.financialreport.expense;
    requires aisco.donation.core;
    requires aisco.donation.confirmation;
    requires aisco.blog.core;
    requires aisco.beneficiary.core;
    requires aisco.beneficiary.pesertadidik;
    requires aisco.programreport.core;
}