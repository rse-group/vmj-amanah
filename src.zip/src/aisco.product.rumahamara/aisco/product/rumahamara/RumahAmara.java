package aisco.product.rumahamara;

import java.util.ArrayList;

import vmj.routing.route.VMJServer;
import vmj.routing.route.Router;
import vmj.hibernate.integrator.HibernateUtil;
import org.hibernate.cfg.Configuration;

import auth.token.TokenResourceFactory;
import auth.token.core.TokenResource;
import auth.management.RoleResourceFactory;
import auth.management.core.RoleResource;
import auth.management.UserResourceFactory;
import auth.management.core.UserResource;
import auth.management.UserRoleResourceFactory;
import auth.management.core.UserRoleResource;
import aisco.program.ProgramResourceFactory;
import aisco.program.core.ProgramResource;
import aisco.chartofaccount.ChartOfAccountResourceFactory;
import aisco.chartofaccount.core.ChartOfAccountResource;
import aisco.financialreport.FinancialReportResourceFactory;
import aisco.financialreport.core.FinancialReportResource;
import aisco.donation.DonationResourceFactory;
import aisco.donation.core.DonationResource;
import aisco.blog.BlogResourceFactory;
import aisco.blog.core.BlogResource;
import aisco.beneficiary.BeneficiaryResourceFactory;
import aisco.beneficiary.core.BeneficiaryResource;
import aisco.programreport.ProgramReportResourceFactory;
import aisco.programreport.core.ProgramReportResource;

public class RumahAmara {

	public static void main(String[] args) {

		// get hostAddress and portnum from env var
        // ex:
        // AMANAH_HOST_BE --> "localhost"
        // AMANAH_PORT_BE --> 7776
		String hostAddress= getEnvVariableHostAddress("AMANAH_HOST_BE");
        int portNum = getEnvVariablePortNumber("AMANAH_PORT_BE");
        activateServer(hostAddress, portNum);

		Configuration configuration = new Configuration();
		// panggil setter setelah membuat object dari kelas Configuration
        // ex:
        // AMANAH_DB_URL --> jdbc:postgresql://localhost:5432/superorg
        // AMANAH_DB_USERNAME --> postgres
        // AMANAH_DB_PASSWORD --> postgres123
		setDBProperties("AMANAH_DB_URL", "url", configuration);
        setDBProperties("AMANAH_DB_USERNAME", "username", configuration);
        setDBProperties("AMANAH_DB_PASSWORD","password", configuration);

		configuration.addAnnotatedClass(auth.storage.core.Storage.class);
		configuration.addAnnotatedClass(auth.storage.core.StorageComponent.class);
		configuration.addAnnotatedClass(auth.storage.core.StorageDecorator.class);
		configuration.addAnnotatedClass(auth.storage.core.StorageImpl.class);
		configuration.addAnnotatedClass(auth.storage.hibernate.StorageImpl.class);
		configuration.addAnnotatedClass(auth.token.core.Token.class);
		configuration.addAnnotatedClass(auth.token.core.TokenComponent.class);
		configuration.addAnnotatedClass(auth.token.core.TokenDecorator.class);
		configuration.addAnnotatedClass(auth.token.core.TokenImpl.class);
		configuration.addAnnotatedClass(auth.management.core.Role.class);
		configuration.addAnnotatedClass(auth.management.core.RoleComponent.class);
		configuration.addAnnotatedClass(auth.management.core.RoleDecorator.class);
		configuration.addAnnotatedClass(auth.management.core.RoleImpl.class);
		configuration.addAnnotatedClass(auth.management.core.User.class);
		configuration.addAnnotatedClass(auth.management.core.UserComponent.class);
		configuration.addAnnotatedClass(auth.management.core.UserDecorator.class);
		configuration.addAnnotatedClass(auth.management.core.UserImpl.class);
		configuration.addAnnotatedClass(auth.management.core.UserRole.class);
		configuration.addAnnotatedClass(auth.management.core.UserRoleComponent.class);
		configuration.addAnnotatedClass(auth.management.core.UserRoleDecorator.class);
		configuration.addAnnotatedClass(auth.management.core.UserRoleImpl.class);
		configuration.addAnnotatedClass(auth.management.classic.UserImpl.class);
		configuration.addAnnotatedClass(auth.management.social.UserImpl.class);
		configuration.addAnnotatedClass(auth.token.hmac.TokenImpl.class);
		configuration.addAnnotatedClass(auth.verifier.core.Verifier.class);
		configuration.addAnnotatedClass(auth.verifier.core.VerifierComponent.class);
		configuration.addAnnotatedClass(auth.verifier.core.VerifierDecorator.class);
		configuration.addAnnotatedClass(auth.verifier.core.VerifierImpl.class);
		configuration.addAnnotatedClass(auth.verifier.manual.VerifierImpl.class);
		configuration.addAnnotatedClass(auth.verifier.google.VerifierImpl.class);
		configuration.addAnnotatedClass(auth.verifier.altgoogle.VerifierImpl.class);
		configuration.addAnnotatedClass(aisco.program.core.Program.class);
		configuration.addAnnotatedClass(aisco.program.core.ProgramComponent.class);
		configuration.addAnnotatedClass(aisco.program.core.ProgramDecorator.class);
		configuration.addAnnotatedClass(aisco.program.core.ProgramImpl.class);
		configuration.addAnnotatedClass(aisco.program.activity.ProgramImpl.class);
		configuration.addAnnotatedClass(aisco.chartofaccount.core.ChartOfAccount.class);
		configuration.addAnnotatedClass(aisco.chartofaccount.core.ChartOfAccountComponent.class);
		configuration.addAnnotatedClass(aisco.chartofaccount.core.ChartOfAccountDecorator.class);
		configuration.addAnnotatedClass(aisco.chartofaccount.core.ChartOfAccountImpl.class);
		configuration.addAnnotatedClass(aisco.financialreport.core.FinancialReport.class);
		configuration.addAnnotatedClass(aisco.financialreport.core.FinancialReportComponent.class);
		configuration.addAnnotatedClass(aisco.financialreport.core.FinancialReportDecorator.class);
		configuration.addAnnotatedClass(aisco.financialreport.core.FinancialReportImpl.class);
		configuration.addAnnotatedClass(aisco.financialreport.income.FinancialReportImpl.class);
		configuration.addAnnotatedClass(aisco.financialreport.expense.FinancialReportImpl.class);
		configuration.addAnnotatedClass(aisco.donation.core.Donation.class);
		configuration.addAnnotatedClass(aisco.donation.core.DonationComponent.class);
		configuration.addAnnotatedClass(aisco.donation.core.DonationDecorator.class);
		configuration.addAnnotatedClass(aisco.donation.core.DonationImpl.class);
		configuration.addAnnotatedClass(aisco.donation.confirmation.DonationImpl.class);
		configuration.addAnnotatedClass(aisco.blog.core.Blog.class);
		configuration.addAnnotatedClass(aisco.blog.core.BlogComponent.class);
		configuration.addAnnotatedClass(aisco.blog.core.BlogDecorator.class);
		configuration.addAnnotatedClass(aisco.blog.core.BlogImpl.class);
		configuration.addAnnotatedClass(aisco.beneficiary.core.Beneficiary.class);
		configuration.addAnnotatedClass(aisco.beneficiary.core.BeneficiaryComponent.class);
		configuration.addAnnotatedClass(aisco.beneficiary.core.BeneficiaryDecorator.class);
		configuration.addAnnotatedClass(aisco.beneficiary.core.BeneficiaryImpl.class);
		configuration.addAnnotatedClass(aisco.beneficiary.pesertadidik.BeneficiaryImpl.class);
		configuration.addAnnotatedClass(aisco.programreport.core.ProgramReport.class);
		configuration.addAnnotatedClass(aisco.programreport.core.ProgramReportComponent.class);
		configuration.addAnnotatedClass(aisco.programreport.core.ProgramReportDecorator.class);
		configuration.addAnnotatedClass(aisco.programreport.core.ProgramReportImpl.class);

		configuration.buildMappings();
		HibernateUtil.buildSessionFactory(configuration);

		createObjectsAndBindEndPoints();
	}

	public static void activateServer(String hostName, int portNumber) {
		VMJServer vmjServer = VMJServer.getInstance(hostName, portNumber);
		try {
			vmjServer.startServerGeneric();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	public static void createObjectsAndBindEndPoints() {
		System.out.println("== CREATING OBJECTS AND BINDING ENDPOINTS ==");
		TokenResource tokenTokenResource = TokenResourceFactory
			.createTokenResource("auth.token.core.TokenResourceImpl"
			);
		
		RoleResource managementRoleResource = RoleResourceFactory
			.createRoleResource("auth.management.core.RoleResourceImpl"
			);
		
		UserResource managementUserResource = UserResourceFactory
			.createUserResource("auth.management.core.UserResourceImpl"
			);
		
		UserRoleResource managementUserRoleResource = UserRoleResourceFactory
			.createUserRoleResource("auth.management.core.UserRoleResourceImpl"
			);
		
		UserResource classicUserResource = UserResourceFactory
			.createUserResource("auth.management.classic.UserResourceImpl"
			,
			UserResourceFactory.createUserResource("auth.management.core.UserResourceImpl"));
		
		UserResource socialUserResource = UserResourceFactory
			.createUserResource("auth.management.social.UserResourceImpl"
			,
			UserResourceFactory.createUserResource("auth.management.core.UserResourceImpl"));
		
		ProgramResource activityProgramResource = ProgramResourceFactory
			.createProgramResource("aisco.program.activity.ProgramResourceImpl"
			);
		
		ChartOfAccountResource chartofaccountChartOfAccountResource = ChartOfAccountResourceFactory
			.createChartOfAccountResource("aisco.chartofaccount.core.ChartOfAccountResourceImpl"
			);
		
		FinancialReportResource financialreportFinancialReportResource = FinancialReportResourceFactory
			.createFinancialReportResource("aisco.financialreport.core.FinancialReportResourceImpl"
			);
		
		FinancialReportResource incomeFinancialReportResource = FinancialReportResourceFactory
			.createFinancialReportResource("aisco.financialreport.income.FinancialReportResourceImpl"
			,
			FinancialReportResourceFactory.createFinancialReportResource("aisco.financialreport.core.FinancialReportResourceImpl"));
		
		FinancialReportResource expenseFinancialReportResource = FinancialReportResourceFactory
			.createFinancialReportResource("aisco.financialreport.expense.FinancialReportResourceImpl"
			,
			FinancialReportResourceFactory.createFinancialReportResource("aisco.financialreport.core.FinancialReportResourceImpl"));
		
		DonationResource donationDonationResource = DonationResourceFactory
			.createDonationResource("aisco.donation.core.DonationResourceImpl"
			);
		
		DonationResource confirmationDonationResource = DonationResourceFactory
			.createDonationResource("aisco.donation.confirmation.DonationResourceImpl"
			,
			DonationResourceFactory.createDonationResource("aisco.donation.core.DonationResourceImpl"));
		
		BlogResource blogBlogResource = BlogResourceFactory
			.createBlogResource("aisco.blog.core.BlogResourceImpl"
			);
		
		BeneficiaryResource beneficiaryBeneficiaryResource = BeneficiaryResourceFactory
			.createBeneficiaryResource("aisco.beneficiary.core.BeneficiaryResourceImpl"
			);
		
		BeneficiaryResource pesertadidikBeneficiaryResource = BeneficiaryResourceFactory
			.createBeneficiaryResource("aisco.beneficiary.pesertadidik.BeneficiaryResourceImpl"
			,
			BeneficiaryResourceFactory.createBeneficiaryResource("aisco.beneficiary.core.BeneficiaryResourceImpl"));
		
		ProgramReportResource programreportProgramReportResource = ProgramReportResourceFactory
			.createProgramReportResource("aisco.programreport.core.ProgramReportResourceImpl"
			);
		

		System.out.println("programreportProgramReportResource endpoints binding");
		Router.route(programreportProgramReportResource);
		
		System.out.println("pesertadidikBeneficiaryResource endpoints binding");
		Router.route(pesertadidikBeneficiaryResource);
		
		System.out.println("beneficiaryBeneficiaryResource endpoints binding");
		Router.route(beneficiaryBeneficiaryResource);
		
		System.out.println("blogBlogResource endpoints binding");
		Router.route(blogBlogResource);
		
		System.out.println("confirmationDonationResource endpoints binding");
		Router.route(confirmationDonationResource);
		
		System.out.println("donationDonationResource endpoints binding");
		Router.route(donationDonationResource);
		
		System.out.println("expenseFinancialReportResource endpoints binding");
		Router.route(expenseFinancialReportResource);
		
		System.out.println("incomeFinancialReportResource endpoints binding");
		Router.route(incomeFinancialReportResource);
		
		System.out.println("financialreportFinancialReportResource endpoints binding");
		Router.route(financialreportFinancialReportResource);
		
		System.out.println("chartofaccountChartOfAccountResource endpoints binding");
		Router.route(chartofaccountChartOfAccountResource);
		
		System.out.println("activityProgramResource endpoints binding");
		Router.route(activityProgramResource);
		
		System.out.println("socialUserResource endpoints binding");
		Router.route(socialUserResource);
		
		System.out.println("classicUserResource endpoints binding");
		Router.route(classicUserResource);
		
		System.out.println("managementRoleResource endpoints binding");
		Router.route(managementRoleResource);
		
		System.out.println("managementUserResource endpoints binding");
		Router.route(managementUserResource);
		
		System.out.println("managementUserRoleResource endpoints binding");
		Router.route(managementUserRoleResource);
		
		System.out.println("tokenTokenResource endpoints binding");
		Router.route(tokenTokenResource);
		
	}

	public static void setDBProperties(String varname, String typeProp, Configuration configuration) {
		String varNameValue = System.getenv(varname);
		String propertyName = String.format("hibernate.connection.%s",typeProp);
		if (varNameValue != null) {
			configuration.setProperty(propertyName, varNameValue);
		} else {
			String hibernatePropertyVal = configuration.getProperty(propertyName);
			if (hibernatePropertyVal == null) {
				String error_message = String.format("Please check '%s' in your local environment variable or "
                	+ "'hibernate.connection.%s' in your 'hibernate.properties' file!", varname, typeProp);
            	System.out.println(error_message);
			}
		}
	}

	// if the env variable for server host is null, use localhost instead.
    public static String getEnvVariableHostAddress(String varname_host){
            String hostAddress = System.getenv(varname_host)  != null ? System.getenv(varname_host) : "localhost"; // Host
            return hostAddress;
    }

    // try if the environment variable for port number is null, use 7776 instead
    public static int getEnvVariablePortNumber(String varname_port){
            String portNum = System.getenv(varname_port)  != null? System.getenv(varname_port)  : "7776"; //PORT
            int portNumInt = Integer.parseInt(portNum);
            return portNumInt;
    }

}
