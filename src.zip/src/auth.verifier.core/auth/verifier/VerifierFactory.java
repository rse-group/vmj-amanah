package auth.verifier;

public class VerifierFactory extends vmj.auth.verifiers.VerifierFactory {
	
}
