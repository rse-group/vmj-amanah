package auth.verifier.core;

public interface Verifier extends vmj.auth.verifiers.Verifier {
    
}
