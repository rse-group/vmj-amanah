package auth.management.core;

public interface User extends vmj.auth.model.core.User {

}
