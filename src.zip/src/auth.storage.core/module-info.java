module auth.storage.core {
	exports auth.storage;
	exports auth.storage.core;
	
	requires java.logging;
	requires vmj.auth;
}