package auth.storage.core;

public interface Storage extends vmj.auth.storages.Storage {

}
