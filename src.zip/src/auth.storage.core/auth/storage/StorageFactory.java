package auth.storage;

public class StorageFactory extends vmj.auth.storages.StorageFactory {
	
}
